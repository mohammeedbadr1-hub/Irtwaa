# ارتواء (Native Android project)
Offline Arabic water tracker starter project, Java + Android SDK.

Build:
1. Open this folder using Android Studio (recent version).
2. Install Android SDK platform 35 and build tools.
3. Build > Build APK(s).
4. For a release APK, Build > Generate Signed Bundle/APK > APK, create/store a keystore.

Permissions in manifest intentionally omit INTERNET. The code is a starter implementation and needs device testing, particularly alarm scheduling, notification permission, reminder time-window enforcement and history-day rollover before release. Exact alarm behavior can require user grant on Android 12+; battery exemption is not programmatically requested.
